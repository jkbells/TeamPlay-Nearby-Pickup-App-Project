---
name: Expo DevTools warning
description: Metro can run successfully even when the optional React Native DevTools binary cannot load a system GLib library.
---

The Expo development server may log a React Native DevTools installation error about missing `libglib-2.0.so.0` while Metro, the web preview, and Expo Go QR flow still start normally.

**Why:** The DevTools binary is optional for the app runtime; treating this warning as a startup failure would create unnecessary environment work.

**How to apply:** If the Expo workflow reaches the QR code and web bundle after this warning, verify the app preview and continue unless there are separate runtime or bundling errors.