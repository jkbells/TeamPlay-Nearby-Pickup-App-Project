import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Sport, useGameStore } from '@/context/GameContext';
import { useColors } from '@/hooks/useColors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const sports: Sport[] = ['Basketball', 'Soccer', 'Volleyball', 'Pickleball'];
const playerCounts = [6, 8, 10, 12, 14];

export default function CreateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { createGame } = useGameStore();
  const [sport, setSport] = useState<Sport>('Basketball');
  const [location, setLocation] = useState('Dolores Park Courts');
  const [date, setDate] = useState('2026-09-19');
  const [time, setTime] = useState('10:00 AM');
  const [maxPlayers, setMaxPlayers] = useState(10);

  const handleCreate = async () => {
    if (!location.trim() || !date.trim() || !time.trim()) {
      Alert.alert('Almost there', 'Add a location, date, and start time.');
      return;
    }
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    createGame({
      sport,
      location,
      startsAt: `${date}T${time.includes('PM') ? '18:00' : '10:00'}:00`,
      maxPlayers,
    });
    router.replace('/');
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 120 }]}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>HOST A GAME</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Get the crew moving.</Text>
          </View>
          <View style={[styles.headerMark, { backgroundColor: colors.primary }]}>
            <Feather name="plus" size={20} color={colors.primaryForeground} />
          </View>
        </View>

        <Text style={[styles.label, { color: colors.foreground }]}>What are you playing?</Text>
        <View style={styles.sportGrid}>
          {sports.map((item) => {
            const active = item === sport;
            return (
              <Pressable
                key={item}
                testID={`sport-${item}`}
                onPress={() => setSport(item)}
                style={[
                  styles.sportOption,
                  { backgroundColor: active ? colors.foreground : colors.card, borderColor: active ? colors.foreground : colors.border },
                ]}
              >
                <Feather
                  name={item === 'Basketball' ? 'circle' : item === 'Soccer' ? 'globe' : item === 'Volleyball' ? 'disc' : 'target'}
                  size={18}
                  color={active ? colors.primary : colors.mutedForeground}
                />
                <Text style={[styles.sportOptionText, { color: active ? colors.background : colors.foreground }]}>{item}</Text>
                {active ? <Feather name="check" size={15} color={colors.primary} /> : null}
              </Pressable>
            );
          })}
        </View>

        <Text style={[styles.label, { color: colors.foreground }]}>Where?</Text>
        <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="map-pin" size={18} color={colors.mutedForeground} />
          <TextInput
            testID="location-input"
            value={location}
            onChangeText={setLocation}
            placeholder="Court, park, or field"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground }]}
          />
        </View>

        <Text style={[styles.label, { color: colors.foreground }]}>When?</Text>
        <View style={styles.twoColumns}>
          <View style={[styles.inputWrap, styles.flexInput, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="calendar" size={17} color={colors.mutedForeground} />
            <TextInput
              testID="date-input"
              value={date}
              onChangeText={setDate}
              placeholder="YYYY-MM-DD"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.foreground }]}
            />
          </View>
          <View style={[styles.inputWrap, styles.flexInput, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="clock" size={17} color={colors.mutedForeground} />
            <TextInput
              testID="time-input"
              value={time}
              onChangeText={setTime}
              placeholder="10:00 AM"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { color: colors.foreground }]}
            />
          </View>
        </View>

        <Text style={[styles.label, { color: colors.foreground }]}>How many players?</Text>
        <View style={styles.countRow}>
          {playerCounts.map((count) => {
            const active = count === maxPlayers;
            return (
              <Pressable
                key={count}
                testID={`player-count-${count}`}
                onPress={() => setMaxPlayers(count)}
                style={[styles.countOption, { backgroundColor: active ? colors.primary : colors.card, borderColor: active ? colors.primary : colors.border }]}
              >
                <Text style={[styles.countText, { color: active ? colors.primaryForeground : colors.foreground }]}>{count}</Text>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.balanceNote, { backgroundColor: `${colors.primary}35` }]}>
          <Feather name="shuffle" size={19} color={colors.foreground} />
          <View style={styles.balanceCopy}>
            <Text style={[styles.balanceTitle, { color: colors.foreground }]}>Fair teams, automatically</Text>
            <Text style={[styles.balanceBody, { color: colors.mutedForeground }]}>
              Once players join, PickUp will split teams using everyone&apos;s self-rated skill.
            </Text>
          </View>
        </View>

        <Pressable
          testID="create-game"
          onPress={handleCreate}
          style={({ pressed }) => [styles.createButton, { backgroundColor: colors.foreground }, pressed && { opacity: 0.82 }]}
        >
          <Text style={[styles.createButtonText, { color: colors.background }]}>Create game</Text>
          <Feather name="arrow-right" size={18} color={colors.primary} />
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 31 },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 1.4 },
  title: { fontSize: 29, lineHeight: 34, fontWeight: '700', marginTop: 7, maxWidth: 270 },
  headerMark: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  label: { fontSize: 14, fontWeight: '700', marginBottom: 11, marginTop: 22 },
  sportGrid: { gap: 9 },
  sportOption: { minHeight: 50, borderRadius: 14, borderWidth: 1, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  sportOptionText: { flex: 1, fontSize: 14, fontWeight: '600' },
  inputWrap: { minHeight: 53, borderRadius: 15, borderWidth: 1, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  input: { flex: 1, fontSize: 14, minHeight: 52 },
  twoColumns: { flexDirection: 'row', gap: 9 },
  flexInput: { flex: 1, paddingHorizontal: 11 },
  countRow: { flexDirection: 'row', gap: 8 },
  countOption: { flex: 1, minHeight: 46, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  countText: { fontSize: 14, fontWeight: '700' },
  balanceNote: { marginTop: 27, borderRadius: 16, padding: 15, flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  balanceCopy: { flex: 1 },
  balanceTitle: { fontSize: 13, fontWeight: '700' },
  balanceBody: { fontSize: 12, lineHeight: 17, marginTop: 4 },
  createButton: { minHeight: 56, borderRadius: 16, marginTop: 24, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  createButtonText: { fontSize: 15, fontWeight: '700' },
});