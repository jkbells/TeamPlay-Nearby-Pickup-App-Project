import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGameStore } from '@/context/GameContext';
import { useColors } from '@/hooks/useColors';

const skillLabels = ['Just starting', 'Getting there', 'Comfortable', 'Strong player', 'Very competitive'];

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { profile, updateProfile } = useGameStore();

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.content, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 }]}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR PICKUP PROFILE</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Set the right level.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Your self-rating helps make every game feel fair. No leaderboards, no pressure.
        </Text>

        <View style={[styles.profileCard, { backgroundColor: colors.foreground }]}>
          <View style={[styles.largeAvatar, { backgroundColor: colors.primary }]}>
            <Text style={[styles.largeAvatarText, { color: colors.primaryForeground }]}>
              {profile.name.charAt(0).toUpperCase()}
            </Text>
          </View>
          <View style={styles.profileCardCopy}>
            <Text style={styles.profileName}>{profile.name}</Text>
            <View style={styles.locationLine}>
              <Feather name="map-pin" size={13} color="#AEB9B3" />
              <Text style={styles.locationText}>{profile.neighborhood}</Text>
            </View>
          </View>
          <Feather name="edit-2" size={16} color="#AEB9B3" />
        </View>

        <Text style={[styles.label, { color: colors.foreground }]}>Your skill level</Text>
        <View style={styles.skillList}>
          {[1, 2, 3, 4, 5].map((level) => {
            const active = profile.skill === level;
            return (
              <Pressable
                key={level}
                testID={`skill-${level}`}
                onPress={() => updateProfile({ skill: level })}
                style={[
                  styles.skillRow,
                  { backgroundColor: active ? `${colors.primary}30` : colors.card, borderColor: active ? colors.primary : colors.border },
                ]}
              >
                <View style={[styles.skillNumber, { backgroundColor: active ? colors.primary : colors.secondary }]}>
                  <Text style={[styles.skillNumberText, { color: active ? colors.primaryForeground : colors.mutedForeground }]}>{level}</Text>
                </View>
                <Text style={[styles.skillLabel, { color: colors.foreground }]}>{skillLabels[level - 1]}</Text>
                {active ? <Feather name="check-circle" size={18} color={colors.foreground} /> : null}
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.preferenceRow, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
          <View style={[styles.preferenceIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="bell" size={17} color={colors.foreground} />
          </View>
          <View style={styles.preferenceCopy}>
            <Text style={[styles.preferenceTitle, { color: colors.foreground }]}>Game reminders</Text>
            <Text style={[styles.preferenceBody, { color: colors.mutedForeground }]}>
              Get a nudge when a game fills or is about to start
            </Text>
          </View>
          <Switch
            testID="reminders-switch"
            value={profile.reminders}
            onValueChange={(reminders) => updateProfile({ reminders })}
            trackColor={{ false: colors.muted, true: colors.primary }}
            thumbColor={profile.reminders ? colors.primaryForeground : colors.mutedForeground}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20 },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 1.4 },
  title: { fontSize: 29, lineHeight: 34, fontWeight: '700', marginTop: 7 },
  subtitle: { fontSize: 14, lineHeight: 20, marginTop: 9, maxWidth: 350 },
  profileCard: { borderRadius: 21, padding: 17, marginTop: 26, flexDirection: 'row', alignItems: 'center' },
  largeAvatar: { width: 54, height: 54, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  largeAvatarText: { fontSize: 22, fontWeight: '700' },
  profileCardCopy: { flex: 1, marginLeft: 13 },
  profileName: { color: '#FFFFFF', fontSize: 17, fontWeight: '700' },
  locationLine: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 5 },
  locationText: { color: '#AEB9B3', fontSize: 12 },
  label: { fontSize: 14, fontWeight: '700', marginTop: 28, marginBottom: 11 },
  skillList: { gap: 8 },
  skillRow: { minHeight: 52, borderRadius: 15, borderWidth: 1, padding: 8, flexDirection: 'row', alignItems: 'center' },
  skillNumber: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  skillNumberText: { fontSize: 14, fontWeight: '700' },
  skillLabel: { flex: 1, marginLeft: 11, fontSize: 14, fontWeight: '600' },
  preferenceRow: { borderTopWidth: 1, borderBottomWidth: 1, paddingVertical: 17, marginTop: 29, flexDirection: 'row', alignItems: 'center' },
  preferenceIcon: { width: 37, height: 37, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  preferenceCopy: { flex: 1, marginLeft: 11, paddingRight: 8 },
  preferenceTitle: { fontSize: 14, fontWeight: '700' },
  preferenceBody: { fontSize: 12, lineHeight: 17, marginTop: 3 },
});