import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Game,
  getSportColor,
  getSportIcon,
  Sport,
  useGameStore,
} from '@/context/GameContext';
import { useColors } from '@/hooks/useColors';

const sports: Array<'All' | Sport> = [
  'All',
  'Basketball',
  'Soccer',
  'Volleyball',
  'Pickleball',
];

function GameCard({ game }: { game: Game }) {
  const colors = useColors();
  const { toggleJoin } = useGameStore();
  const joined = game.players.some((player) => player.isCurrentUser);
  const isFull = game.players.length >= game.maxPlayers;
  const sportColor = getSportColor(game.sport);

  const handleJoin = async () => {
    await Haptics.selectionAsync();
    toggleJoin(game.id);
  };

  return (
    <Pressable
      testID={`game-${game.id}`}
      onPress={() => router.push(`/game/${game.id}`)}
      style={({ pressed }) => [
        styles.gameCard,
        { backgroundColor: colors.card, borderColor: colors.border },
        pressed && styles.pressed,
      ]}
    >
      <View style={styles.cardTopline}>
        <View style={[styles.sportIcon, { backgroundColor: `${sportColor}20` }]}>
          <Feather name={getSportIcon(game.sport)} size={17} color={sportColor} />
        </View>
        <View style={styles.cardToplineText}>
          <Text style={[styles.sportLabel, { color: sportColor }]}>
            {game.sport.toUpperCase()}
          </Text>
          <Text style={[styles.gameTitle, { color: colors.foreground }]} numberOfLines={1}>
            {game.title}
          </Text>
        </View>
        <Text style={[styles.distance, { color: colors.mutedForeground }]}>
          {game.distance}
        </Text>
      </View>

      <View style={styles.infoRow}>
        <Feather name="calendar" size={15} color={colors.mutedForeground} />
        <Text style={[styles.infoText, { color: colors.foreground }]}>{game.startsAt}</Text>
      </View>
      <View style={styles.infoRow}>
        <Feather name="map-pin" size={15} color={colors.mutedForeground} />
        <Text style={[styles.infoText, { color: colors.mutedForeground }]} numberOfLines={1}>
          {game.location}
        </Text>
      </View>

      <View style={[styles.cardBottom, { borderTopColor: colors.border }]}>
        <View>
          <Text style={[styles.spotsNumber, { color: colors.foreground }]}>
            {game.players.length}
            <Text style={{ color: colors.mutedForeground }}> / {game.maxPlayers}</Text>
          </Text>
          <Text style={[styles.spotsLabel, { color: colors.mutedForeground }]}>players in</Text>
        </View>
        <Pressable
          testID={`join-${game.id}`}
          onPress={handleJoin}
          disabled={isFull && !joined}
          style={({ pressed }) => [
            styles.joinButton,
            {
              backgroundColor: joined
                ? colors.secondary
                : isFull
                  ? colors.muted
                  : colors.primary,
            },
            pressed && styles.pressed,
          ]}
        >
          <Text
            style={[
              styles.joinButtonText,
              { color: joined || isFull ? colors.foreground : colors.primaryForeground },
            ]}
          >
            {joined ? 'Joined' : isFull ? 'Full' : 'Join game'}
          </Text>
          {!joined && !isFull ? (
            <Feather name="arrow-up-right" size={15} color={colors.primaryForeground} />
          ) : null}
        </Pressable>
      </View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { games, profile, hydrated, notice, clearNotice } = useGameStore();
  const [selectedSport, setSelectedSport] = useState<'All' | Sport>('All');

  const filteredGames = useMemo(
    () =>
      selectedSport === 'All'
        ? games
        : games.filter((game) => game.sport === selectedSport),
    [games, selectedSport],
  );

  if (!hydrated) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 110 }}
      >
        <View style={[styles.header, { paddingTop: insets.top + 18 }]}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>MY CITY · SAN FRANCISCO</Text>
            <Text style={[styles.greeting, { color: colors.foreground }]}>
              Hey {profile.name}
            </Text>
          </View>
          <Pressable
            testID="profile-avatar"
            onPress={() => router.push('/profile')}
            style={({ pressed }) => [
              styles.avatar,
              { backgroundColor: colors.primary },
              pressed && styles.pressed,
            ]}
          >
            <Text style={[styles.avatarText, { color: colors.primaryForeground }]}>
              {profile.name.charAt(0).toUpperCase()}
            </Text>
          </Pressable>
        </View>

        {notice ? (
          <Pressable
            testID="notice-banner"
            onPress={clearNotice}
            style={[styles.notice, { backgroundColor: colors.foreground }]}
          >
            <Feather name="check-circle" size={16} color={colors.primary} />
            <Text style={styles.noticeText}>{notice}</Text>
            <Feather name="x" size={15} color="#AEB9B3" />
          </Pressable>
        ) : null}

        <View style={[styles.hero, { backgroundColor: colors.foreground }]}>
          <View style={styles.heroCopy}>
            <Text style={[styles.heroKicker, { color: colors.primary }]}>PLAY MORE. PLAN LESS.</Text>
            <Text style={styles.heroTitle}>Find your people.</Text>
            <Text style={styles.heroBody}>
              Open games around {profile.neighborhood} with room for you.
            </Text>
          </View>
          <View style={styles.heroBall}>
            <Feather name="activity" size={34} color={colors.foreground} />
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Games near you</Text>
            <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
              {filteredGames.length} open {filteredGames.length === 1 ? 'game' : 'games'} this week
            </Text>
          </View>
          <Pressable onPress={() => router.push('/create')} testID="create-shortcut">
            <Text style={[styles.linkText, { color: colors.foreground }]}>Create one</Text>
          </Pressable>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterRow}
        >
          {sports.map((sport) => {
            const active = selectedSport === sport;
            return (
              <Pressable
                key={sport}
                testID={`filter-${sport}`}
                onPress={() => setSelectedSport(sport)}
                style={[
                  styles.filterChip,
                  {
                    backgroundColor: active ? colors.foreground : colors.card,
                    borderColor: active ? colors.foreground : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.filterText,
                    { color: active ? colors.background : colors.mutedForeground },
                  ]}
                >
                  {sport}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={styles.gamesList}>
          {filteredGames.length ? (
            filteredGames.map((game) => <GameCard key={game.id} game={game} />)
          ) : (
            <View style={[styles.emptyState, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="search" size={23} color={colors.mutedForeground} />
              <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No games here yet</Text>
              <Text style={[styles.emptyBody, { color: colors.mutedForeground }]}>
                Start one and make it easier for your neighborhood to show up.
              </Text>
              <Pressable onPress={() => router.push('/create')} style={[styles.emptyButton, { backgroundColor: colors.primary }]}>
                <Text style={[styles.emptyButtonText, { color: colors.primaryForeground }]}>Create a game</Text>
              </Pressable>
            </View>
          )}
        </View>
      </ScrollView>

      <Pressable
        testID="floating-create"
        onPress={() => router.push('/create')}
        style={({ pressed }) => [
          styles.floatingButton,
          { backgroundColor: colors.primary, bottom: insets.bottom + 86 },
          pressed && styles.pressed,
        ]}
      >
        <Feather name="plus" size={21} color={colors.primaryForeground} />
        <Text style={[styles.floatingText, { color: colors.primaryForeground }]}>New game</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  eyebrow: { fontSize: 11, letterSpacing: 1.4, fontWeight: '700' },
  greeting: { fontSize: 30, lineHeight: 36, fontWeight: '700', marginTop: 4 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 17, fontWeight: '700' },
  hero: {
    marginHorizontal: 20,
    minHeight: 164,
    borderRadius: 26,
    padding: 22,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
  },
  heroCopy: { flex: 1, paddingRight: 10 },
  heroKicker: { fontSize: 10, letterSpacing: 1.5, fontWeight: '700', marginBottom: 10 },
  heroTitle: { color: '#FFFFFF', fontSize: 29, lineHeight: 33, fontWeight: '700' },
  heroBody: { color: '#B5C2BB', fontSize: 14, lineHeight: 20, marginTop: 10 },
  heroBall: {
    width: 74,
    height: 74,
    borderRadius: 37,
    backgroundColor: '#B7E34A',
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ rotate: '-15deg' }],
  },
  notice: {
    marginHorizontal: 20,
    marginBottom: 14,
    minHeight: 42,
    borderRadius: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 9,
  },
  noticeText: { color: '#FFFFFF', flex: 1, fontSize: 13, fontWeight: '600' },
  sectionHeader: {
    paddingHorizontal: 20,
    paddingTop: 28,
    paddingBottom: 15,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  sectionTitle: { fontSize: 21, fontWeight: '700' },
  sectionSubtitle: { fontSize: 13, marginTop: 4 },
  linkText: { fontSize: 13, fontWeight: '700', textDecorationLine: 'underline' },
  filterRow: { paddingHorizontal: 20, gap: 8, paddingBottom: 17 },
  filterChip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18, borderWidth: 1 },
  filterText: { fontSize: 13, fontWeight: '600' },
  gamesList: { paddingHorizontal: 20, gap: 12 },
  gameCard: { borderRadius: 20, borderWidth: 1, padding: 16 },
  pressed: { opacity: 0.76 },
  cardTopline: { flexDirection: 'row', alignItems: 'center' },
  sportIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  cardToplineText: { flex: 1, marginLeft: 11 },
  sportLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.1 },
  gameTitle: { fontSize: 16, fontWeight: '700', marginTop: 3 },
  distance: { fontSize: 12, fontWeight: '600' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  infoText: { fontSize: 13, flex: 1 },
  cardBottom: { borderTopWidth: 1, marginTop: 16, paddingTop: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  spotsNumber: { fontSize: 18, fontWeight: '700' },
  spotsLabel: { fontSize: 11, marginTop: 1 },
  joinButton: { minHeight: 38, paddingHorizontal: 15, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7 },
  joinButtonText: { fontSize: 13, fontWeight: '700' },
  emptyState: { borderRadius: 20, borderWidth: 1, padding: 28, alignItems: 'center' },
  emptyTitle: { fontSize: 17, fontWeight: '700', marginTop: 12 },
  emptyBody: { fontSize: 13, lineHeight: 19, textAlign: 'center', marginTop: 6, maxWidth: 250 },
  emptyButton: { borderRadius: 12, paddingHorizontal: 18, paddingVertical: 11, marginTop: 18 },
  emptyButtonText: { fontSize: 13, fontWeight: '700' },
  floatingButton: { position: 'absolute', right: 20, borderRadius: 22, paddingHorizontal: 17, height: 46, flexDirection: 'row', alignItems: 'center', gap: 7, shadowColor: '#10251D', shadowOpacity: 0.16, shadowRadius: 10, shadowOffset: { width: 0, height: 5 }, elevation: 4 },
  floatingText: { fontSize: 13, fontWeight: '700' },
});
