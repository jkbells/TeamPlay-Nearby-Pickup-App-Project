import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getSportColor, getSportIcon, makeTeams, useGameStore } from '@/context/GameContext';
import { useColors } from '@/hooks/useColors';

function TeamColumn({ label, players, color }: { label: string; players: string[]; color: string }) {
  const colors = useColors();
  return (
    <View style={[styles.teamColumn, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.teamHeader}>
        <View style={[styles.teamDot, { backgroundColor: color }]} />
        <Text style={[styles.teamLabel, { color: colors.foreground }]}>{label}</Text>
        <Text style={[styles.teamCount, { color: colors.mutedForeground }]}>{players.length}</Text>
      </View>
      {players.map((player) => (
        <View key={player} style={[styles.playerRow, { borderTopColor: colors.border }]}>
          <View style={[styles.miniAvatar, { backgroundColor: `${color}25` }]}>
            <Text style={[styles.miniAvatarText, { color }]}>{player.charAt(0)}</Text>
          </View>
          <Text style={[styles.playerName, { color: colors.foreground }]} numberOfLines={1}>{player}</Text>
        </View>
      ))}
    </View>
  );
}

export default function GameDetailScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getGame, toggleJoin } = useGameStore();
  const game = getGame(id ?? '');

  if (!game) {
    return (
      <View style={[styles.missing, { backgroundColor: colors.background }]}>
        <Text style={[styles.missingTitle, { color: colors.foreground }]}>Game not found</Text>
        <Pressable onPress={() => router.back()} style={[styles.backButton, { backgroundColor: colors.foreground }]}>
          <Text style={[styles.backButtonText, { color: colors.background }]}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const joined = game.players.some((player) => player.isCurrentUser);
  const [teamA, teamB] = makeTeams(game.players);
  const sportColor = getSportColor(game.sport);

  const handleJoin = async () => {
    await Haptics.selectionAsync();
    toggleJoin(game.id);
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 35 }}
      >
        <View style={[styles.topBar, { paddingTop: insets.top + 14 }]}>
          <Pressable testID="back-button" onPress={() => router.back()} style={styles.iconButton}>
            <Feather name="arrow-left" size={20} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.topBarLabel, { color: colors.mutedForeground }]}>GAME DETAILS</Text>
          <View style={styles.iconButton} />
        </View>

        <View style={styles.detailHeader}>
          <View style={[styles.detailSportIcon, { backgroundColor: `${sportColor}20` }]}>
            <Feather name={getSportIcon(game.sport)} size={24} color={sportColor} />
          </View>
          <Text style={[styles.sportLabel, { color: sportColor }]}>{game.sport.toUpperCase()}</Text>
          <Text style={[styles.detailTitle, { color: colors.foreground }]}>{game.title}</Text>
          <Text style={[styles.hostText, { color: colors.mutedForeground }]}>Hosted by {game.hostName}</Text>
        </View>

        <View style={[styles.detailsGrid, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.detailItem}>
            <Feather name="calendar" size={17} color={colors.mutedForeground} />
            <View>
              <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>WHEN</Text>
              <Text style={[styles.detailItemValue, { color: colors.foreground }]}>{game.startsAt}</Text>
            </View>
          </View>
          <View style={styles.detailItem}>
            <Feather name="map-pin" size={17} color={colors.mutedForeground} />
            <View style={styles.detailItemCopy}>
              <Text style={[styles.detailItemLabel, { color: colors.mutedForeground }]}>WHERE</Text>
              <Text style={[styles.detailItemValue, { color: colors.foreground }]} numberOfLines={1}>{game.location}</Text>
            </View>
          </View>
        </View>

        <View style={styles.teamsHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Balanced teams</Text>
            <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
              Snake draft based on self-rated skill
            </Text>
          </View>
          <View style={[styles.playerPill, { backgroundColor: colors.secondary }]}>
            <Feather name="users" size={14} color={colors.foreground} />
            <Text style={[styles.playerPillText, { color: colors.foreground }]}>{game.players.length}/{game.maxPlayers}</Text>
          </View>
        </View>

        {game.players.length >= 2 ? (
          <View style={styles.teams}>
            <TeamColumn label="Team Lime" players={teamA.map((player) => player.name)} color={colors.primary} />
            <TeamColumn label="Team Coral" players={teamB.map((player) => player.name)} color="#FF775E" />
          </View>
        ) : (
          <View style={[styles.waitingCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name="users" size={22} color={colors.mutedForeground} />
            <Text style={[styles.waitingTitle, { color: colors.foreground }]}>Teams appear at two players</Text>
            <Text style={[styles.waitingBody, { color: colors.mutedForeground }]}>Invite a friend or join the game to get started.</Text>
          </View>
        )}

        <Pressable
          testID="detail-join"
          onPress={handleJoin}
          style={({ pressed }) => [
            styles.detailJoinButton,
            { backgroundColor: joined ? colors.secondary : colors.foreground },
            pressed && { opacity: 0.8 },
          ]}
        >
          <Text style={[styles.detailJoinText, { color: joined ? colors.foreground : colors.background }]}>
            {joined ? 'Leave game' : 'Join this game'}
          </Text>
          <Feather name={joined ? 'log-out' : 'arrow-up-right'} size={18} color={joined ? colors.foreground : colors.primary} />
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  topBar: { paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  iconButton: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  topBarLabel: { fontSize: 11, letterSpacing: 1.4, fontWeight: '700' },
  detailHeader: { alignItems: 'center', paddingHorizontal: 20, paddingTop: 22, paddingBottom: 24 },
  detailSportIcon: { width: 65, height: 65, borderRadius: 23, alignItems: 'center', justifyContent: 'center', marginBottom: 15 },
  sportLabel: { fontSize: 11, fontWeight: '700', letterSpacing: 1.4 },
  detailTitle: { fontSize: 28, lineHeight: 33, fontWeight: '700', textAlign: 'center', marginTop: 6 },
  hostText: { fontSize: 13, marginTop: 8 },
  detailsGrid: { marginHorizontal: 20, borderRadius: 18, borderWidth: 1, padding: 16, gap: 18 },
  detailItem: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  detailItemCopy: { flex: 1 },
  detailItemLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 1.1 },
  detailItemValue: { fontSize: 14, fontWeight: '600', marginTop: 4 },
  teamsHeading: { marginHorizontal: 20, marginTop: 28, marginBottom: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontSize: 20, fontWeight: '700' },
  sectionSubtitle: { fontSize: 12, marginTop: 4 },
  playerPill: { borderRadius: 14, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', gap: 6, alignItems: 'center' },
  playerPillText: { fontSize: 12, fontWeight: '700' },
  teams: { marginHorizontal: 20, gap: 10 },
  teamColumn: { borderRadius: 18, borderWidth: 1, overflow: 'hidden' },
  teamHeader: { paddingHorizontal: 14, paddingVertical: 13, flexDirection: 'row', alignItems: 'center', gap: 8 },
  teamDot: { width: 9, height: 9, borderRadius: 5 },
  teamLabel: { flex: 1, fontSize: 13, fontWeight: '700' },
  teamCount: { fontSize: 12, fontWeight: '600' },
  playerRow: { borderTopWidth: 1, paddingHorizontal: 14, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  miniAvatar: { width: 27, height: 27, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  miniAvatarText: { fontSize: 12, fontWeight: '700' },
  playerName: { fontSize: 13, fontWeight: '600' },
  waitingCard: { marginHorizontal: 20, borderRadius: 18, borderWidth: 1, padding: 25, alignItems: 'center' },
  waitingTitle: { fontSize: 15, fontWeight: '700', marginTop: 10 },
  waitingBody: { fontSize: 13, textAlign: 'center', lineHeight: 18, marginTop: 5 },
  detailJoinButton: { marginHorizontal: 20, minHeight: 55, borderRadius: 16, marginTop: 25, paddingHorizontal: 19, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  detailJoinText: { fontSize: 15, fontWeight: '700' },
  missing: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  missingTitle: { fontSize: 22, fontWeight: '700' },
  backButton: { borderRadius: 13, paddingHorizontal: 18, paddingVertical: 12, marginTop: 18 },
  backButtonText: { fontSize: 14, fontWeight: '700' },
});