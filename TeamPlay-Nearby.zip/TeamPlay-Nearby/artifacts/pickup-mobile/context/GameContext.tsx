import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

export type Sport = 'Basketball' | 'Soccer' | 'Volleyball' | 'Pickleball';

export type Player = {
  id: string;
  name: string;
  skill: number;
  isCurrentUser?: boolean;
};

export type Game = {
  id: string;
  sport: Sport;
  title: string;
  location: string;
  neighborhood: string;
  startsAt: string;
  maxPlayers: number;
  hostName: string;
  distance: string;
  players: Player[];
  createdAt: string;
};

type Profile = {
  name: string;
  neighborhood: string;
  skill: number;
  reminders: boolean;
};

type GameContextValue = {
  games: Game[];
  profile: Profile;
  hydrated: boolean;
  notice: string | null;
  createGame: (input: {
    sport: Sport;
    location: string;
    startsAt: string;
    maxPlayers: number;
  }) => void;
  toggleJoin: (gameId: string) => void;
  updateProfile: (updates: Partial<Profile>) => void;
  getGame: (gameId: string) => Game | undefined;
  clearNotice: () => void;
};

const GAMES_KEY = 'pickup-games-v1';
const PROFILE_KEY = 'pickup-profile-v1';

const initialProfile: Profile = {
  name: 'Alex',
  neighborhood: 'Mission District',
  skill: 3,
  reminders: true,
};

const initialGames: Game[] = [
  {
    id: 'mission-hoops',
    sport: 'Basketball',
    title: 'Saturday Hoops',
    location: 'Dolores Park Courts',
    neighborhood: 'Mission District',
    startsAt: 'Sat, Sep 19 · 10:00 AM',
    maxPlayers: 10,
    hostName: 'Jordan',
    distance: '0.4 mi',
    createdAt: '2026-09-12T10:00:00.000Z',
    players: [
      { id: 'jordan', name: 'Jordan', skill: 4 },
      { id: 'maya', name: 'Maya', skill: 3 },
      { id: 'leo', name: 'Leo', skill: 2 },
      { id: 'sam', name: 'Sam', skill: 4 },
      { id: 'nina', name: 'Nina', skill: 3 },
      { id: 'alex', name: 'Alex', skill: 3, isCurrentUser: true },
    ],
  },
  {
    id: 'riverside-soccer',
    sport: 'Soccer',
    title: 'Riverside 5-a-side',
    location: 'Kezar Field',
    neighborhood: 'Sunset',
    startsAt: 'Sun, Sep 20 · 4:30 PM',
    maxPlayers: 10,
    hostName: 'Chris',
    distance: '1.2 mi',
    createdAt: '2026-09-11T10:00:00.000Z',
    players: [
      { id: 'chris', name: 'Chris', skill: 4 },
      { id: 'riley', name: 'Riley', skill: 3 },
      { id: 'tay', name: 'Tay', skill: 2 },
    ],
  },
  {
    id: 'pier-volleyball',
    sport: 'Volleyball',
    title: 'Sunset Rally',
    location: 'Ocean Beach Courts',
    neighborhood: 'Richmond',
    startsAt: 'Fri, Sep 18 · 6:00 PM',
    maxPlayers: 12,
    hostName: 'Priya',
    distance: '2.1 mi',
    createdAt: '2026-09-10T10:00:00.000Z',
    players: [
      { id: 'priya', name: 'Priya', skill: 3 },
      { id: 'dev', name: 'Dev', skill: 3 },
      { id: 'cam', name: 'Cam', skill: 2 },
      { id: 'jo', name: 'Jo', skill: 4 },
      { id: 'eli', name: 'Eli', skill: 3 },
    ],
  },
  {
    id: 'eastside-pickleball',
    sport: 'Pickleball',
    title: 'Beginner-friendly doubles',
    location: 'Mission Playground',
    neighborhood: 'Mission District',
    startsAt: 'Tue, Sep 22 · 6:30 PM',
    maxPlayers: 8,
    hostName: 'Avery',
    distance: '0.8 mi',
    createdAt: '2026-09-09T10:00:00.000Z',
    players: [
      { id: 'avery', name: 'Avery', skill: 2 },
      { id: 'morgan', name: 'Morgan', skill: 1 },
    ],
  },
];

function makeId() {
  return `${Date.now().toString()}-${Math.random().toString(36).slice(2, 8)}`;
}

function formatCreatedGameDate(value: string) {
  const date = new Date(value);
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: PropsWithChildren) {
  const [games, setGames] = useState<Game[]>(initialGames);
  const [profile, setProfile] = useState<Profile>(initialProfile);
  const [hydrated, setHydrated] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    Promise.all([AsyncStorage.getItem(GAMES_KEY), AsyncStorage.getItem(PROFILE_KEY)])
      .then(([storedGames, storedProfile]) => {
        if (!mounted) return;
        if (storedGames) setGames(JSON.parse(storedGames) as Game[]);
        if (storedProfile) {
          setProfile({ ...initialProfile, ...(JSON.parse(storedProfile) as Profile) });
        }
      })
      .catch(() => {
        if (mounted) setNotice('We could not restore your local games.');
      })
      .finally(() => {
        if (mounted) setHydrated(true);
      });

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    void AsyncStorage.setItem(GAMES_KEY, JSON.stringify(games));
  }, [games, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    void AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  }, [profile, hydrated]);

  const createGame = useCallback(
    (input: {
      sport: Sport;
      location: string;
      startsAt: string;
      maxPlayers: number;
    }) => {
      const game: Game = {
        id: makeId(),
        sport: input.sport,
        title: `${input.sport} pickup`,
        location: input.location.trim(),
        neighborhood: profile.neighborhood,
        startsAt: formatCreatedGameDate(input.startsAt),
        maxPlayers: input.maxPlayers,
        hostName: profile.name,
        distance: 'Nearby',
        createdAt: new Date().toISOString(),
        players: [
          {
            id: 'alex',
            name: profile.name,
            skill: profile.skill,
            isCurrentUser: true,
          },
        ],
      };
      setGames((current) => [game, ...current]);
      setNotice('Game created. Your first player is already in.');
    },
    [profile],
  );

  const toggleJoin = useCallback(
    (gameId: string) => {
      setGames((current) =>
        current.map((game) => {
          if (game.id !== gameId) return game;
          const isJoined = game.players.some((player) => player.isCurrentUser);
          if (isJoined) {
            setNotice('You left the game.');
            return {
              ...game,
              players: game.players.filter((player) => !player.isCurrentUser),
            };
          }
          if (game.players.length >= game.maxPlayers) {
            setNotice('This game is full. Try another nearby game.');
            return game;
          }
          const nextPlayers = [
            ...game.players,
            {
              id: 'alex',
              name: profile.name,
              skill: profile.skill,
              isCurrentUser: true,
            },
          ];
          if (nextPlayers.length === game.maxPlayers) {
            setNotice('Game full. Everyone is in — see you on the court.');
          } else {
            setNotice(`You're in. ${game.maxPlayers - nextPlayers.length} spots left.`);
          }
          return { ...game, players: nextPlayers };
        }),
      );
    },
    [profile.name, profile.skill],
  );

  const updateProfile = useCallback((updates: Partial<Profile>) => {
    setProfile((current) => ({ ...current, ...updates }));
  }, []);

  const getGame = useCallback(
    (gameId: string) => games.find((game) => game.id === gameId),
    [games],
  );

  const clearNotice = useCallback(() => setNotice(null), []);

  const value = useMemo(
    () => ({
      games,
      profile,
      hydrated,
      notice,
      createGame,
      toggleJoin,
      updateProfile,
      getGame,
      clearNotice,
    }),
    [
      games,
      profile,
      hydrated,
      notice,
      createGame,
      toggleJoin,
      updateProfile,
      getGame,
      clearNotice,
    ],
  );

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGameStore() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGameStore must be used inside GameProvider');
  }
  return context;
}

export function getSportIcon(sport: Sport) {
  switch (sport) {
    case 'Basketball':
      return 'circle';
    case 'Soccer':
      return 'globe';
    case 'Volleyball':
      return 'disc';
    case 'Pickleball':
      return 'target';
  }
}

export function getSportColor(sport: Sport) {
  switch (sport) {
    case 'Basketball':
      return '#FF775E';
    case 'Soccer':
      return '#67B7A2';
    case 'Volleyball':
      return '#F2B557';
    case 'Pickleball':
      return '#8C7CF0';
  }
}

export function makeTeams(players: Player[]) {
  const sorted = [...players].sort((a, b) => b.skill - a.skill);
  const teams: [Player[], Player[]] = [[], []];
  sorted.forEach((player, index) => {
    const round = Math.floor(index / 2);
    const position = index % 2;
    teams[round % 2 === 0 ? position : 1 - position].push(player);
  });
  return teams;
}