/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#14211C',
    tint: '#B7E34A',

    // Core surfaces
    background: '#F7F8F2',
    foreground: '#14211C',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#14211C',

    // Primary action color (buttons, links, active states)
    primary: '#B7E34A',
    primaryForeground: '#14211C',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E9EFE8',
    secondaryForeground: '#14211C',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#DDE6DE',
    mutedForeground: '#718078',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#FF775E',
    accentForeground: '#FFFFFF',

    // Destructive actions (delete, error states)
    destructive: '#D94D4D',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#DCE5DC',
    input: '#DCE5DC',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 14,
};

export default colors;
